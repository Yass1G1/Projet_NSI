"""
    Platform Game / Jump Game - "A Little Dinosaur Game"
    
        The Dinosaur Game (also known as the Chrome Dino or T-Rex Game) is a browser game
    developed by Google and built into the Google Chrome web browser.
    The player guides a pixelated Tyrannosaurus rex across a side-scrolling landscape,
    avoiding obstacles to achieve a higher score.
    The game was created by members of the Chrome UX team in 2014,
    and is intended to be accessed by hitting the space bar when Google Chrome is offline.
    (https://en.wikipedia.org/wiki/Dinosaur_Game)

    _link = "https://github.com/Yass1G1/Projet_NSI"
    _ver = "a0.4"
    _date = "03/2022"
    _author = "t0rtue"
    _language = "english"
    _police = "cherif.otf"

    Bugs :
        Aucun Signalés

    Tâche à Faire :
    
    Finir le Menu
        -Faire les différentes options du menu
    
    Finir le jeu
        -Faire le highscore
    
    Améliorer le Responsive
"""