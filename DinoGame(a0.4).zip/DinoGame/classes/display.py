from classes.menu import *
from classes.exec import *
import time

pygame.init()
pygame.font.init()

# Variables - Informations

FPS = FPS_EXEC
SOUND_LEVEL = 100
GRAPHIC_LEVEL = 100
DEFAULT_SIZE = [1280, 720]


# Definition de la Fenêtre

class Screen:
    def __init__(self):
        # running variables
        self.window_loop = True
        self.playing, self.running = True, False
        self.UP_KEY, self.DOWN_KEY, self.LEFT_KEY, self.RIGHT_KEY = False, False, False, False
        self.ENTER_KEY, self.ESCAPE_KEY, self.SUPPR_KEY = False, False, False
        self.MENU, self.EXEC, self.EXEC_VERIF = MENU, EXEC, True
        # others variables
        self.size = DEFAULT_SIZE
        self.title = "Dino Game"
        self.display = pygame.Surface(self.size)
        self.screen = pygame.display.set_mode(self.size)
        pygame.display.set_caption(self.title)
        self.difficulty = "normal"
        # size links variables
        self.s1w, self.s1h = self.size[0], self.size[1]
        self.s2w, self.s2h = int(self.s1w / 2), int(self.s1h / 2)
        self.s3w, self.s3h = int(self.s1w / 3), int(self.s1h / 3)
        self.s4w, self.s4h = int(self.s1w / 4), int(self.s1h / 4)
        self.s5w, self.s5h = int(self.s1w / 5), int(self.s1h / 5)
        self.s6w, self.s6h = int(self.s1w / 6), int(self.s1h / 6)
        self.s7w, self.s7h = int(self.s1w / 7), int(self.s1h / 7)
        self.s8w, self.s8h = int(self.s1w / 8), int(self.s1h / 8)
        self.s9w, self.s9h = int(self.s1w / 9), int(self.s1h / 9)
        self.sAw, self.sAh = int(self.s1w / 10), int(self.s1h / 10)
        self.sBw, self.sBh = int(self.s1w / 11), int(self.s1h / 11)
        self.sCw, self.sCh = int(self.s1w / 12), int(self.s1h / 12)
        self.sDw, self.sDh = int(self.s1w / 13), int(self.s1h / 13)
        self.sEw, self.sEh = int(self.s1w / 14), int(self.s1h / 14)
        self.sFw, self.sFh = int(self.s1w / 15), int(self.s1h / 15)
        self.s_w, self.s_h = int(self.s1w / 16), int(self.s1h / 16)
        self.active_bg = True
        self.refresh = 0
        # init variables
        self.menu = State(self)
        self.exec = Run(self)
        self.FPS = FPS
        self.SOUND_LEVEL = SOUND_LEVEL

    def check_events(self):
        """
        This function is for check the keys events.
        :return: none
        """
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.playing, self.running = False, False
                self.menu.run_display = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.ESCAPE_KEY = True
                    self.active_bg = True
                if event.key == pygame.K_RETURN:
                    self.ENTER_KEY = True
                    self.active_bg = True
                if event.key == pygame.K_DELETE:
                    self.SUPPR_KEY = True
                    self.active_bg = True
                if event.key == pygame.K_UP:
                    self.UP_KEY = True
                    self.active_bg = True
                    self.menu.run_display = True
                if event.key == pygame.K_DOWN:
                    self.DOWN_KEY = True
                    self.active_bg = True
                    self.menu.run_display = True
                if event.key == pygame.K_LEFT:
                    self.LEFT_KEY = True
                    self.active_bg = True
                if event.key == pygame.K_RIGHT:
                    self.RIGHT_KEY = True
                    self.active_bg = True

    def reset_keys(self):
        """
        This function is for reset all keys events.
        :return: none
        """
        self.UP_KEY, self.DOWN_KEY, self.LEFT_KEY, self.RIGHT_KEY = False, False, False, False
        self.ENTER_KEY, self.ESCAPE_KEY = False, False

    def text(self, text, pos, font, color1, color2):
        """
        This function is to draw automatically a text on screen.
        :param text: the text of the text
        :param pos: the position (top_left) of the text
        :param font: the font of the text
        :param color1: the color of the text
        :param color2: the color of text's background
        :return: none
        """
        if font == "MENU":
            var_text = MENU_FONT.render(text, False, color1, color2)
            self.screen.blit(var_text, pos)
        elif font == "STAT":
            var_text = STAT_FONT.render(text, False, color1, color2)
            self.screen.blit(var_text, pos)
        elif font == "TITLE":
            var_text = TITLE_FONT.render(text, False, color1, color2)
            self.screen.blit(var_text, pos)
        elif font == "TEXT":
            var_text = TEXT_FONT.render(text, False, color1, color2)
            self.screen.blit(var_text, pos)

    def text_fps(self, text, pos, font, color1, color2):
        """
        This function is to draw automatically a text who is actualised for each fps on screen.
        :param text: the text of the text
        :param pos: the position (top_left) of the text
        :param font: the font of the text
        :param color1: the color of the text
        :param color2: the color of text's background
        :return: none
        """
        if font == "MENU":
            var_text = MENU_FONT.render(text, False, color1, color2)
        elif font == "STAT":
            var_text = STAT_FONT.render(text, False, color1, color2)
        elif font == "TITLE":
            var_text = TITLE_FONT.render(text, False, color1, color2)
        elif font == "TEXT":
            var_text = TEXT_FONT.render(text, False, color1, color2)
        self.screen.blit(var_text, pos)

    def rect(self, color, pos, scale, thickness, round_corner):
        """
        This function is to draw automatically a rectangle on the screen.
        :param color: the color of the rectangle
        :param pos: the position (top_left) of the rectangle
        :param scale: the width and the height of the rectangle
        :param thickness: the line border thickness, if the value is zero, the rectangle is filled
        :param round_corner: the value of how the corners are rounded
        :return: none
        """
        var_rect = pygame.Rect(pos[0], pos[1], scale[0], scale[1])
        pygame.draw.rect(self.display, color, var_rect, thickness, round_corner)

    def image(self, path, name, pos):
        """
        This function is to draw automatically an image on the screen.
        :param path: the path of the image
        :param name: the name of the image
        :param pos: the position of the image
        :return: none
        """
        if self.active_bg:
            var_image = pygame.image.load(path, name).convert()
            self.screen.blit(var_image, pos)

    def image_move(self, path, name, pos1, pos2, color):
        """
        This function is to move an image on the screen
        :param path: the path of the image
        :param name: the name of the image
        :param pos1: the position of the initial image
        :param pos2: the position of the substitute image
        :return: none
        """
        if name == "Dino_R.png" or name == "Dino_L.png" or name == "Dino_J.png":
            self.rect(color, pos1, (64, 64), 0, 0)
        elif name == "Dino_R_D.png" or name == "Dino_L_D.png":
            self.rect(color, pos1, (100, 64), 0, 0)
        elif name == "Cactus.png":
            self.rect(color, pos1, (64, 100), 0, 0)
        elif name == "Ptero_L.png" or name == "Ptero_D.png" or name == "Ptero_T.png":
            self.rect(color, pos1, (1000, 64), 0, 0)
        var_image = pygame.image.load(path, name).convert()
        self.screen.blit(var_image, pos2)


scr = Screen()