from classes.update import *


def start_run():
    """
    This function is the list of instruction when the program start.
    :return: none
    """
    scr.menu.display_menu()


def start_run_exec():
    """
    This function is the list of instructions when the program with exec file start.
    :return:
    """
    scr.exec.display_exec()


def frame_run():
    """
    This function is the list of instructions for each frames.
    :return: none
    """
    while scr.playing:
        scr.menu.check_inputs()
        if scr.SUPPR_KEY:
            scr.playing = False
        scr.reset_keys()
        if scr.menu.run_display:
            scr.menu.display_menu()


def frame_run_exec():
    """
    This function is the list of instructions for each frames with exec python file.
    :return: none
    """
    while scr.playing:
        if scr.SUPPR_KEY:
            scr.playing = False
        scr.reset_keys()
        scr.check_events()
        if scr.exec.run_display:
            scr.exec.display_exec()