import time

import pygame
from random import *

FPS_EXEC = 60
EXEC = False


# Variables - Raccourcis

BLACK = (0, 0, 0)
BACK_BLACK = (31, 31, 31)
GRAY = (63, 63, 63)
BACK_GRAY = (127, 127, 127)
BACK_WHITE = (191, 191, 191)
WHITE = (255, 255, 255)
RED = (255, 0, 0)

pygame.font.init()
MENU_FONT = pygame.font.Font("./docs/fonts/cherif.otf", 25)
STAT_FONT = pygame.font.Font("./docs/fonts/cherif.otf", 60)
TITLE_FONT = pygame.font.Font("./docs/fonts/cherif.otf", 75)
TEXT_FONT = pygame.font.Font("./docs/fonts/cherif.otf", 40)


class Exec:
    def __init__(self, game):
        self.game = game
        self.run_display = True
        # dinosaur variables
        self.dino_pos, self.dino_pos_cache = [self.game.s8w, 5*self.game.s6h-64], []
        self.dino_w, self.dino_h = 64, 64
        self.dino_dead, self.dino_move, self.dino_down = False, False, False
        self.dino_jump, self.dino_jump_time = False, 0
        # exec variables

    def draw_dinosaur(self):
        """
        This function is for draw the dinosaur on the screen.
        :return: none
        """
        if self.dino_down:
            if not self.dino_move and not self.dino_jump:
                self.game.image_move("./docs/images/Dino_R_D.png", "Dino_R_D.png", self.dino_pos, self.dino_pos, WHITE)
                self.dino_move = True
            elif self.dino_move:
                self.game.image_move("./docs/images/Dino_L_D.png", "Dino_L_D.png", self.dino_pos, self.dino_pos, WHITE)
                self.dino_move = False
        elif not self.dino_down and not self.dino_jump:
            if not self.dino_move:
                self.game.image_move("./docs/images/Dino_R.png", "Dino_R.png", self.dino_pos, self.dino_pos, WHITE)
                self.dino_move = True
            elif self.dino_move:
                self.game.image_move("./docs/images/Dino_L.png", "Dino_L.png", self.dino_pos, self.dino_pos, WHITE)
                self.dino_move = False
        elif self.dino_jump:
            self.game.image_move("./docs/images/Dino_J.png", "Dino_J.png", self.dino_pos_cache, self.dino_pos, WHITE)
            self.dino_move = False

    def blit_screen(self):
        """
        This function is for reload the screen.
        :return: none
        """
        pygame.display.update()
        self.game.screen.blit(self.game.display, (0, 0))
        self.game.reset_keys()


class Run(Exec):
    def __init__(self, game):
        Exec.__init__(self, game)
        # base variables
        # run variables
        self.stat_x, self.stat_y = self.game.s8w + 50, self.game.s6h + 100
        self.cactus_x, self.cactus_y, self.ptero_x, self.ptero_y = 1500, 5*self.game.s6h-100, 10000, self.game.s6h*4
        self.cactus_w, self.cactus_h, self.ptero_w, self.ptero_h = 64, 100, 100, 64
        self.cactus_x_base, self.ptero_x_base, self.ptero_fps = 1500, 10000, 0
        self.cactus_time, self.ptero_time, self.ptero_h_ = 0, 0, [3*self.game.s6h, 7*self.game.sCh, 4*self.game.s6h]
        self.score = 0
        self.time = 0
        self.var_time = 0
        self.jump_time = 0
        self.speed = 1

    def ground_draw(self):
        """
        This function is for draw the ground.
        :return: none
        """
        self.game.rect(GRAY, (0, 5*self.game.s6h), (self.game.s1w, self.game.s6h), 0, 0)

    def cactus_draw(self):
        """
        This function is for draw a cactus.
        :return: none
        """
        self.game.image_move("./docs/images/Cactus.png", "Cactus.png", (self.cactus_x-1, self.cactus_y), (self.cactus_x, self.cactus_y), WHITE)

    def ptero_draw(self):
        """
        This function is for draw a pterodactyl.
        :return: none
        """
        if 0 <= self.ptero_fps < 10:
            self.game.image_move("./docs/images/Ptero_L.png", "Ptero_L.png", (self.ptero_x-1, self.ptero_y), (self.ptero_x, self.ptero_y), WHITE)
        elif 10 <= self.ptero_fps < 20:
            self.game.image_move("./docs/images/Ptero_D.png", "Ptero_D.png", (self.ptero_x - 1, self.ptero_y), (self.ptero_x, self.ptero_y), WHITE)
        elif 20 <= self.ptero_fps < 30:
            self.game.image_move("./docs/images/Ptero_T.png", "Ptero_T.png", (self.ptero_x - 1, self.ptero_y), (self.ptero_x, self.ptero_y), WHITE)

    def cactus_reload(self):
        """
        This function is for reload the position of the cactus.
        :return: none
        """
        if self.cactus_x < 0:
            self.cactus_x_base = randint(self.game.s1w, int(1.5*self.game.s1w))
            self.cactus_x = self.cactus_x_base
            self.cactus_time = 0
        else:
            self.cactus_x = self.cactus_x_base - int(self.cactus_time*self.speed)
            self.cactus_time += 1
            if self.cactus_x < self.game.s1w:
                self.cactus_draw()

    def ptero_reload(self):
        """
        This function is for reload the position of the pterodactyl.
        :return: none
        """
        if self.ptero_x < 0:
            self.ptero_x_base = randint(self.game.s1w, 4*self.game.s1w)
            self.ptero_x = self.ptero_x_base
            self.ptero_y = self.ptero_h_[randint(0, 2)]
            self.ptero_time = 0
        else:
            self.ptero_x = self.ptero_x_base - int(self.ptero_time*self.speed)
            self.ptero_time += 1
            if self.ptero_fps < 30:
                self.ptero_fps += 1
            else:
                self.ptero_fps = 0
            if self.ptero_x < self.game.s1w:
                self.ptero_draw()

    def speed_reload(self):
        """
        This function is for reload the speed.
        :return: none
        """
        if self.game.difficulty == "easy":
            self.speed += 0.00025
        elif self.game.difficulty == "normal":
            self.speed += 0.0005
        elif self.game.difficulty == "hard":
            self.speed += 0.001

    def score_and_distance_reload(self):
        """
        This function is for reload the score and the distance.
        :return: none
        """
        self.game.text("Score : ", (self.game.s1w-500, 10), "TEXT", BLACK, WHITE)
        self.game.text_fps(str(self.score), (self.game.s1w - 300, 10), "TEXT", BLACK, WHITE)
        self.game.text("Distance : ", (self.game.s1w-500, 60), "TEXT", BLACK, WHITE)
        self.game.text_fps(str(self.time), (self.game.s1w - 250, 60), "TEXT", BLACK, WHITE)
        self.game.text("Difficulty : ", (self.game.s1w-500, 110), "TEXT", BLACK, WHITE)
        self.game.text_fps(str(self.game.difficulty), (self.game.s1w - 200, 110), "TEXT", BLACK, WHITE)
        self.score += 1
        self.var_time += 1
        if self.var_time == FPS_EXEC:
            self.time += 1

    def dead_dinosaur(self):
        """
        This function is the passage of the dead of the dinosaur to the stat's menu.
        :return: none
        """
        self.dino_dead = True
        self.game.display.fill(BLACK)
        self.blit_screen()
        self.game.text("Game Over...", (self.game.s3w, self.game.s2h), "TITLE", WHITE, BLACK)
        self.blit_screen()
        time.sleep(1)
        self.game.display.fill(WHITE)
        self.blit_screen()

    def collision(self):
        """
        This function is for the events when an enemy collide with the dinosaur.
        :return: none
        """
        if (self.dino_pos[0] <= self.cactus_x <= self.dino_pos[0]+self.dino_w) and (self.dino_pos[1] <= 5*self.game.s6h-30 <= self.dino_pos[1]+self.dino_h):
            self.dead_dinosaur()
        elif (self.dino_pos[0] <= self.ptero_x <= self.dino_pos[0]+self.dino_w) and (self.dino_pos[1] <= self.ptero_y <= self.dino_pos[1]+self.dino_h):
            self.dead_dinosaur()
        elif (self.dino_pos[0] <= self.cactus_x+self.cactus_w <= self.dino_pos[0]+self.dino_w) and (self.dino_pos[1] <= self.cactus_y+self.cactus_h <= self.dino_pos[1]+self.dino_h):
            self.dead_dinosaur()
        elif (self.dino_pos[0] <= self.ptero_x+self.ptero_w <= self.dino_pos[0]+self.dino_w) and (self.dino_pos[1] <= self.ptero_y+self.ptero_h <= self.dino_pos[1]+self.dino_h):
            self.dead_dinosaur()

    def jump_dinosaur(self):
        if self.game.UP_KEY and self.dino_jump == False:
            self.dino_jump = True
            self.dino_jump_time = 0
            self.jump_time += 1

    def dinosaur_reload(self):
        if self.dino_jump:
            self.dino_pos_cache = self.dino_pos
            if self.dino_jump_time < 60:
                self.dino_pos[1] -= 4
                self.dino_jump_time += 1
            elif 60 <= self.dino_jump_time < 120:
                self.dino_pos[1] += 4
                self.dino_jump_time += 1
            else:
                self.dino_jump = False
        else:
            if self.game.DOWN_KEY:
                self.dino_down = True
            else:
                self.dino_down = False
        self.draw_dinosaur()

    def stat_restart(self):
        self.stat_x, self.stat_y = self.game.s8w + 50, self.game.s6h + 100
        self.cactus_x, self.cactus_y, self.ptero_x, self.ptero_y = 1500, 5 * self.game.s6h - 100, 10000, self.game.s6h * 4
        self.cactus_w, self.cactus_h, self.ptero_w, self.ptero_h = 64, 100, 100, 64
        self.cactus_x_base, self.ptero_x_base, self.ptero_fps = 1500, 10000, 0
        self.cactus_time, self.ptero_time, self.ptero_h_ = 0, 0, [3 * self.game.s6h, 7 * self.game.sCh, 4 * self.game.s6h]
        self.score = 0
        self.time = 0
        self.var_time = 0
        self.jump_time = 0
        self.speed = 1

    def check_inputs(self):
        """
        This function is for check the inputs.
        :return: none
        """
        if self.game.ENTER_KEY:
            self.stat_restart()
            self.dino_dead = False
        elif self.game.ESCAPE_KEY:
            self.game.playing = False
            self.game.MENU = True
            self.game.EXEC = False
            self.game.EXEC_VERIF = True

    def display_exec(self):
        """
        This function is the list of execution for each frame if the run_display of Run is true.
        :return: none
        """
        self.run_display = True
        if self.run_display:
            if self.game.active_bg:
                self.game.display.fill(WHITE)
            if self.dino_dead:
                self.game.rect(BACK_GRAY, (self.game.s8w, self.game.s6h), (6 * self.game.s8w, 4 * self.game.s6h), 0, 0)
                self.game.text("Score : " + str(self.score), (self.game.size[0] / 2 - 200, self.game.s6h), "TITLE", BACK_BLACK, BACK_GRAY)
                self.game.text("Time : " + str(self.time), (self.stat_x, self.stat_y), "MENU", BLACK, BACK_GRAY)
                self.game.text("Jump : " + str(self.jump_time), (self.stat_x, self.stat_y + 50), "MENU", BLACK, BACK_GRAY)
                self.game.text("Restart, Press Enter", (self.stat_x, self.stat_y + 100), "MENU", BLACK, BACK_GRAY)
                self.game.text("Menu, Press Echap", (self.stat_x, self.stat_y + 150), "MENU", BLACK, BACK_GRAY)
                self.check_inputs()
                pygame.display.update()
                self.blit_screen()
            else:
                self.ground_draw()
                self.cactus_reload()
                self.ptero_reload()
                self.speed_reload()
                self.jump_dinosaur()
                self.dinosaur_reload()
                self.score_and_distance_reload()
                self.collision()
                self.blit_screen()
            self.game.active_bg = False