import pygame

# Variables - Raccourcis

MENU = True

BLACK = (0, 0, 0)
BACK_BLACK = (31, 31, 31)
GRAY = (63, 63, 63)
BACK_GRAY = (127, 127, 127)
BACK_WHITE = (191, 191, 191)
WHITE = (223, 223, 223)
RED = (255, 0, 0)

pygame.font.init()
MENU_FONT = pygame.font.Font("./docs/fonts/cherif.otf", 25)
STAT_FONT = pygame.font.Font("./docs/fonts/cherif.otf", 60)
TITLE_FONT = pygame.font.Font("./docs/fonts/cherif.otf", 75)
TEXT_FONT = pygame.font.Font("./docs/fonts/cherif.otf", 40)


class Menu:
    def __init__(self, game):
        self.game = game
        self.mid_w, self.mid_h = int(self.game.size[0] / 2), int(self.game.size[1] / 2)
        self.run_display = True
        self.cursor_rect = pygame.Rect(0, 0, 20, 20)
        self.offset = - 50

    def draw_cursor(self):
        """
        This function is for draw the menu's cursor on the screen.
        :return: none
        """
        self.game.text(">", self.cursor_rect.midtop, "MENU", RED, BACK_GRAY)

    def blit_screen(self):
        """
        This function is for reload the screen.
        :return: none
        """
        pygame.display.update()
        self.game.screen.blit(self.game.display, (0, 0))
        self.game.reset_keys()


class State(Menu):
    def __init__(self, game):
        Menu.__init__(self, game)
        # base variables
        self.state = "start"
        # menu variables
        self.new_x, self.new_y = self.game.s8w + 50, self.game.s6h + 100
        self.options_x, self.options_y = self.game.s8w + 50, self.game.s6h + 150
        self.credits_x, self.credits_y = self.game.s8w + 50, self.game.s6h + 200
        self.quit_x, self.quit_y = self.game.s8w + 50, self.game.s6h + 250
        self.cursor_rect.midtop = (self.new_x + self.offset, self.new_y)
        self.menu_page = 1

    def display_menu(self):
        self.run_display = True
        while self.run_display:
            if self.menu_page == 1:
                self.game.display.fill(WHITE)
                self.game.rect(BACK_GRAY, (self.game.s8w, self.game.s6h), (6 * self.game.s8w, 4 * self.game.s6h), 0, 0)
                self.game.text("Menu :", (self.game.size[0] / 2 - 50, self.game.s6h), "TITLE", BACK_BLACK, BACK_GRAY)
                self.game.text("New Game", (self.new_x, self.new_y), "MENU", BLACK, BACK_GRAY)
                self.game.text("Options", (self.options_x, self.options_y), "MENU", BLACK, BACK_GRAY)
                self.game.text("Credits", (self.credits_x, self.credits_y), "MENU", BLACK, BACK_GRAY)
                self.game.text("Quit", (self.quit_x, self.quit_y), "MENU", BLACK, BACK_GRAY)
                self.draw_cursor()
                self.blit_screen()
                self.run_display = False
            if self.menu_page == 2:
                self.game.display.fill(WHITE)
                self.game.rect(BACK_GRAY, (self.game.s8w, self.game.s6h), (6 * self.game.s8w, 4 * self.game.s6h), 0, 0)
                self.game.text("Options :", (self.game.size[0] / 2 - 50, self.game.s6h), "TITLE", BACK_BLACK, BACK_GRAY)
                self.game.text("FPS : " + str(self.game.FPS), (self.new_x, self.new_y), "MENU", BLACK, BACK_GRAY)
                self.game.text("Window Size : " + str(self.game.size), (self.options_x, self.options_y), "MENU", BLACK, BACK_GRAY)
                self.game.text("Sound Level : " + str(self.game.SOUND_LEVEL), (self.credits_x, self.credits_y), "MENU", BLACK, BACK_GRAY)
                self.game.text("Quit Menu", (self.quit_x, self.quit_y), "MENU", BLACK, BACK_GRAY)
                self.draw_cursor()
                self.blit_screen()
                self.run_display = False

    def move_cursor(self):
        self.game.check_events()
        if self.game.UP_KEY:
            if self.state == "start":
                self.cursor_rect.midtop = (self.new_x - 20, self.quit_y)
                self.state = "quit"
            elif self.state == "options":
                self.cursor_rect.midtop = (self.new_x - 20, self.new_y)
                self.state = "start"
            elif self.state == "credits":
                self.cursor_rect.midtop = (self.new_x - 20, self.options_y)
                self.state = "options"
            elif self.state == "quit":
                self.cursor_rect.midtop = (self.new_x - 20, self.credits_y)
                self.state = "credits"
            self.run_display = True
        if self.game.DOWN_KEY:
            if self.state == "start":
                self.cursor_rect.midtop = (self.new_x - 20, self.options_y)
                self.state = "options"
            elif self.state == "options":
                self.cursor_rect.midtop = (self.new_x - 20, self.credits_y)
                self.state = "credits"
            elif self.state == "credits":
                self.cursor_rect.midtop = (self.new_x - 20, self.quit_y)
                self.state = "quit"
            elif self.state == "quit":
                self.cursor_rect.midtop = (self.new_x - 20, self.new_y)
                self.state = "start"
            self.run_display = True
        if self.game.RIGHT_KEY and self.menu_page == 2:
            if self.state == "start":
                if self.game.FPS == 30:
                    self.game.FPS = 60
            if self.state == "options":
                if self.game.size == [1280, 720]:
                    self.game.size = [1366, 768]
                elif self.game.size == [1366, 768]:
                    self.game.size = [1920, 1080]
                elif self.game.size == [1920, 1080]:
                    self.game.size = [720, 480]
                elif self.game.size == [720, 480]:
                    self.game.size = [1024, 768]
                elif self.game.size == [1024, 768]:
                    self.game.size = [1280, 720]
            if self.state == "credits" and self.game.SOUND_LEVEL <= 99:
                self.game.SOUND_LEVEL += 1
            self.run_display = True
        if self.game.LEFT_KEY and self.menu_page == 2:
            if self.state == "options":
                if self.game.size == [1366, 768]:
                    self.game.size = [1280, 720]
                elif self.game.size == [1920, 1080]:
                    self.game.size = [1366, 768]
                elif self.game.size == [720, 480]:
                    self.game.size = [1920, 1080]
                elif self.game.size == [1024, 768]:
                    self.game.size = [720, 480]
                elif self.game.size == [1280, 720]:
                    self.game.size = [1024, 768]
            if self.state == "credits" and self.game.SOUND_LEVEL >= 1:
                self.game.SOUND_LEVEL -= 1
            self.run_display = True

    def check_inputs(self):
        self.move_cursor()
        if self.game.ENTER_KEY:
            if self.state == "start" and self.menu_page == 1:
                if self.menu_page == 1:
                    self.game.playing = False
                    self.game.MENU = False
                    self.game.EXEC = True
                    self.game.EXEC_VERIF = True
            if self.state == "options" and self.menu_page == 1:
                self.menu_page = 2
                self.game.playing = True
            elif self.state == "credits" and self.menu_page == 1:
                self.menu_page = 3
                self.game.playing = True
            elif self.state == "quit":
                if self.state == 1:
                    self.game.window_loop = False
                    pygame.quit()
                else:
                    self.state = "start"
                    self.menu_page = 1
                self.game.playing = True
            self.run_display = False